<?php
  include("header.php");  //nav bar and logo include home page
?>
<link rel="stylesheet" type="text/css" href="css/mainweel.css">
<div class="home-col1 ">
	  	<h2>[wp] AAW-2244</h2>
	  	<img src="BAJAJ-RE-205cc-motorized-three-wheeler-17.png">
		  	<p>
		  		VEHICLE-bajaj(4stroke)
		  		<br>
		  		DRIVER ID - 1024AAW
		  		<br>
		  		DRIVER NAME - Saman
		  		<br>
		  		TEL.NO - 077xxxxxxxx
		  		<br>
		  		45/= per 1KM
		  	</p>
	  </div><!--home-col1/wheel1-->
	  <div class="home-col1">
	  	<button>
	  		<a href="login.php">CONFRIM your BOOKING>></a>
	  	</button>
	  	</div><!--home-col1/wheel1-->
	  	<div class="home-col2 ">
	  	<h2>[wp] ABW-1244</h2>
	  	<img src="img/threewheel/weel-green.jpg">
		  	<p>
		  		VEHICLE-bajaj(4stroke)
		  		<br>
		  		DRIVER ID - 1014ABW
		  		<br>
		  		DRIVER NAME - Kasun
		  		<br>
		  		TEL.NO - 071xxxxxxxx
		  		<br>
		  		45/= per 1KM
		  	</p>
	  </div><!--home-col2/wheel2-->
	  <div class="home-col2">
	  	<button>
	  		<a href="login.php">CONFRIM your BOOKING>></a>
	  	</button>
	  	</div><!--home-col2/wheel2-->
	  		<div class="home-col3 ">
	  	<h2>[wp] QS-1244</h2>
	  	<img src="img/threewheel/Blue.jpg">
		  	<p>
		  		VEHICLE-bajaj(2stroke)
		  		<br>
		  		DRIVER ID - 1034QS
		  		<br>
		  		DRIVER NAME - Nimal
		  		<br>
		  		TEL.NO - 078xxxxxxxx
		  		<br>
		  		45/= per 1KM
		  	</p>
	  </div><!--home-col3/wheel3-->
	  <div class="home-col3">
	  	<button>
	  		<a href="login.php">CONFRIM your BOOKING>></a>
	  	</button>
	  	</div><!--home-col3/wheel3-->
	  	<div class="home-col4 ">
	  	<h2>[wp] AAA-0044</h2>
	  	<img src="img/threewheel/Black.png">
		  	<p>
		  		VEHICLE-bajaj(2stroke)
		  		<br>
		  		DRIVER ID - 1434AAA
		  		<br>
		  		DRIVER NAME - Mali
		  		<br>
		  		TEL.NO - 070xxxxxxxx
		  		<br>
		  		45/= per 1KM
		  	</p>
	  </div><!--home-col4/wheel4-->
	  <div class="home-col4">
	  	<button>
	  		<a href="login.php">CONFRIM your BOOKING>></a>
	  	</button>
	  	</div><!--home-col4/wheel4-->
	  	<div class="home-col5 ">
	  	<h2>[wp] GB-2244</h2>
	  	<img src="img/threewheel/red.jpg">
		  	<p>
		  		VEHICLE-bajaj(2stroke)
		  		<br>
		  		DRIVER ID - 1934GB
		  		<br>
		  		DRIVER NAME - Raju
		  		<br>
		  		TEL.NO - 075xxxxxxxx
		  		<br>
		  		45/= per 1KM
		  	</p>
	  </div><!--home-col5/wheel5-->
	  <div class="home-col5">
	  	<button>
	  		<a href="login.php">CONFRIM your BOOKING>></a>
	  	</button>
	  	</div><!--home-col5/wheel5-->



<?php
   include("footer.php");   //footer
?>