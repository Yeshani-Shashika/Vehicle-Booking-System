<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" type="text/css" href="css/mainexca.css">
</head>

<body>
   <div class="wrapper">
    <div class="logo">
             <img src="img/45.png">
	</div> <!--logo-->
	
	
	 <div class="home">
	     <nav class="clearfix">
		     <ul>
			     <li><a href="index.php"> home </a></li>
				 <li><a href="maincat.php"> vehicles</a></li>
				 <li><a href="AboutUs.php"> about us</a></li>
				 <li><a href="ContactUs.php"> customer care</a></li>
				 <li><a href="register_1.php">  register now</a></li>
				 <li><a href="select1.php"> login</a></li>
				 <li><a href="select.php"> my account</a></li>
			 </ul>
		 </nav>
		 </div>  <!--home-->
		 
		 <div class="home-col1 ">
	  	<h2>[wp] JB-2244</h2>
	  	<img src="img/excavator/ex1.jpg">
		  	<p>
		  		VEHICLE- CAT
		  		<br>
		  		DRIVER ID - 3024JB
		  		<br>
		  		DRIVER NAME - Saman
		  		<br>
		  		TEL.NO - 077xxxxxxxx
		  		<br>
		  		800/= per 1Hr
		  		
		  	</p>
	  </div><!--home-col1/ex1-->
	  <div class="home-col1">
	  	<button>
	  		<a href="login.php">CONFRIM your BOOKING>></a>
	  	</button>
	  	</div><!--home-col1/ex1-->
	  	<div class="home-col2 ">
	  	<h2>[wp] JC-1244</h2>
	  	<img src="img/excavator/ex2.jpg">
		  	<p>
		  		VEHICLE- KOMATSU
		  		<br>
		  		DRIVER ID - 3014JC
		  		<br>
		  		DRIVER NAME - Kasun
		  		<br>
		  		TEL.NO - 071xxxxxxxx
		  		<br>
		  		800/= per 1Hr
		  		
		  	</p>
	  </div><!--home-col2/ex2-->
	  <div class="home-col2">
	  	<button>
	  		<a href="login.php">CONFRIM your BOOKING>></a>
	  	</button>
	  	</div><!--home-col2/ex2-->
	  		<div class="home-col3 ">
	  	<h2>[wp] JA-1244</h2>
	  	<img src="img/excavator/ex3.jpg">
		  	<p>
		  		VEHICLE- CAT
		  		<br>
		  		DRIVER ID - 3034JA
		  		<br>
		  		DRIVER NAME - Nimal
		  		<br>
		  		TEL.NO - 078xxxxxxxx
		  		<br>
		  		800/= per 1Hr
		  		
		  	</p>
	  </div><!--home-col3/ex3-->
	  <div class="home-col3">
	  	<button>
	  		<a href="login.php">CONFRIM your BOOKING>></a>
	  	</button>
	  	</div><!--home-col3/ex3-->
	  	<div class="home-col4 ">
	  	<h2>[wp] JQ-0044</h2>
	  	<img src="img/excavator/ex4.jpg">
		  	<p>
		  		VEHICLE- SUZUKI
		  		<br>
		  		DRIVER ID - 3434JQ
		  		<br>
		  		DRIVER NAME - Mali
		  		<br>
		  		TEL.NO - 070xxxxxxxx
		  		<br>
		  		800/= per 1Hr
		  		
		  	</p>
	  </div><!--home-col4/ex4-->
	  <div class="home-col4">
	  	<button>
	  		<a href="login.php">CONFRIM your BOOKING>></a>
	  	</button>
	  	</div><!--home-col4/ex4-->
	  	<div class="home-col5 ">
	  	<h2>[wp] JK-0044</h2>
	  	<img src="img/excavator/ex5.jpg">
		  	<p>
		  		VEHICLE- CAT
		  		<br>
		  		DRIVER ID - 3434JK
		  		<br>
		  		DRIVER NAME - Anil
		  		<br>
		  		TEL.NO - 070xxxxxxxx
		  		<br>
		  		800/= per 1Hr
		  		 
		  	</p>
	  </div><!--home-col4/exr5-->
	  <div class="home-col5">
	  	<button>
	  		<a href="login.php">CONFRIM your BOOKING>></a>
	  	</button>
	  	</div><!--home-col4/ex5-->
		 
<?php
  session_start();   //start the session
  include("footer.php");   //footer
?> 	 