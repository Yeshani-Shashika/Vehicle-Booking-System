<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" type="text/css" href="css/mainvan.css">
</head>

<body>
   <div class="wrapper">
    <div class="logo">
             <img src="img/45.png">
	</div> <!--logo-->
	
	
	 <div class="home">
	     <nav class="clearfix">
		     <ul>
			     <li><a href="index.php"> home </a></li>
				 <li><a href="maincat.php"> vehicles</a></li>
				 <li><a href="AboutUs.php"> about us</a></li>
				 <li><a href="ContactUs.php"> customer care</a></li>
				 <li><a href="register_1.php">  register now</a></li>
				 <li><a href="login.php"> login</a></li>
				 <li><a href="select.php"> my account</a></li>
			 </ul>
		 </nav>
		 </div>  <!--home-->
		 
		  <div class="home-col1 ">
	  	<h2>[wp] AAB-2244</h2>
	  	<img src="img/vans/van1.jpg">
		  	<p>
		  		VEHICLE- Custom
		  		<br>
		  		DRIVER ID - 3024AAB
		  		<br>
		  		DRIVER NAME - Saman
		  		<br>
		  		TEL.NO - 077xxxxxxxx
		  		<br>
		  		60/= per 1KM
		  		<br>
		  		A/C
		  	</p>
	  </div><!--home-col1/van1-->
	  <div class="home-col1">
	  	<button>
	  		<a href="login.php">CONFRIM your BOOKING>></a>
	  	</button>
	  	</div><!--home-col1/van1-->
	  	<div class="home-col2 ">
	  	<h2>[wp] CCC-1244</h2>
	  	<img src="img/vans/van2.jpg">
		  	<p>
		  		VEHICLE- Hiace
		  		<br>
		  		DRIVER ID - 3014CCC
		  		<br>
		  		DRIVER NAME - Kasun
		  		<br>
		  		TEL.NO - 071xxxxxxxx
		  		<br>
		  		200/= per 1KM
		  		<br>
		  		A/C
		  	</p>
	  </div><!--home-col2/van2-->
	  <div class="home-col2">
	  	<button>
	  		<a href="login.php">CONFRIM your BOOKING>></a>
	  	</button>
	  	</div><!--home-col2/van2-->
	  		<div class="home-col3 ">
	  	<h2>[wp] AAA-1244</h2>
	  	<img src="img/vans/vans3.jpg">
		  	<p>
		  		VEHICLE- Carevan
		  		<br>
		  		DRIVER ID - 3034AAA
		  		<br>
		  		DRIVER NAME - Nimal
		  		<br>
		  		TEL.NO - 078xxxxxxxx
		  		<br>
		  		60/= per 1KM
		  		<br>
		  		A/C
		  	</p>
	  </div><!--home-col3/van3-->
	  <div class="home-col3">
	  	<button>
	  		<a href="login.php">CONFRIM your BOOKING>></a>
	  	</button>
	  	</div><!--home-col3/van3-->
	  	<div class="home-col4 ">
	  	<h2>[wp] ACA-0044</h2>
	  	<img src="img/vans/van4.jpg">
		  	<p>
		  		VEHICLE- Benz van
		  		<br>
		  		DRIVER ID - 3434ACA
		  		<br>
		  		DRIVER NAME - Mali
		  		<br>
		  		TEL.NO - 070xxxxxxxx
		  		<br>
		  		70/= per 1KM
		  		<br>
		  		A/C
		  	</p>
	  </div><!--home-col4/van4-->
	  <div class="home-col4">
	  	<button>
	  		<a href="login.php">CONFRIM your BOOKING>></a>
	  	</button>
	  	</div><!--home-col4/van4-->
	  	<div class="home-col5 ">
	  	<h2>[wp] ACA-0044</h2>
	  	<img src="img/vans/van5.jpg">
		  	<p>
		  		VEHICLE- Dolpin
		  		<br>
		  		DRIVER ID - 3434ACA
		  		<br>
		  		DRIVER NAME - Mali
		  		<br>
		  		TEL.NO - 070xxxxxxxx
		  		<br>
		  		60/= per 1KM
		  		<br>
		  		A/C 
		  	</p>
	  </div><!--home-col4/van5-->
	  <div class="home-col5">
	  	<button>
	  		<a href="login.php">CONFRIM your BOOKING>></a>
	  	</button>
	  	</div><!--home-col4/van5-->
<?php
  session_start();   //start the session
  include("footer.php");   //footer
?> 	 