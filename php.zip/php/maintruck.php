<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" type="text/css" href="css/maintruck.css">
   
</head>

<body>
   <div class="wrapper">
    <div class="logo">
             <img src="img/45.png">
	</div> <!--logo-->
	
	
	 <div class="home">
	     <nav class="clearfix">
		     <ul>
			     <li><a href="index.php"> home </a></li>
				 <li><a href="maincat.php"> vehicles</a></li>
				 <li><a href="AboutUs.php"> about us</a></li>
				 <li><a href="ContactUs.php"> customer care</a></li>
				 <li><a href="register_1.php">  register now</a></li>
				 <li><a href="login.php"> login</a></li>
				 <li><a href="select.php"> my account</a></li>
			 </ul>
		 </nav>
		 </div>  <!--home-->
		 
		 
		 	  <div class="home-col1 ">
	  	<h2>[wp] JK-2244</h2>
	  	<img src="img/trucks/t1.jpg">
		  	<p>
		  		VEHICLE- TATA
		  		<br>
		  		DRIVER ID - 3024JK
		  		<br>
		  		DRIVER NAME - Nimal
		  		<br>
		  		TEL.NO - 077xxxxxxxx
		  		<br>
		  		1000/= per 1Hr
		  		
		  	</p>
	  </div><!--home-col1/t1-->
	  <div class="home-col1">
	  	<button>
	  		<a href="login.php">CONFRIM your BOOKING>></a>
	  	</button>
	  	</div><!--home-col1/t1-->
	  	<div class="home-col2 ">
	  	<h2>[wp] JZ-1244</h2>
	  	<img src="img/trucks/t2.jpg">
		  	<p>
		  		VEHICLE- TATA
		  		<br>
		  		DRIVER ID - 3014JZ
		  		<br>
		  		DRIVER NAME - Amal
		  		<br>
		  		TEL.NO - 071xxxxxxxx
		  		<br>
		  		1000/= per 1Hr
		  		
		  	</p>
	  </div><!--home-col2/t2-->
	  <div class="home-col2">
	  	<button>
	  		<a href="login.php">CONFRIM your BOOKING>></a>
	  	</button>
	  	</div><!--home-col2/t2-->
	  		<div class="home-col3 ">
	  	<h2>[wp] JZ-1244</h2>
	  	<img src="img/trucks/t3.jpg">
		  	<p>
		  		VEHICLE- CAT
		  		<br>
		  		DRIVER ID - 3034JZ
		  		<br>
		  		DRIVER NAME - Kamal
		  		<br>
		  		TEL.NO - 078xxxxxxxx
		  		<br>
		  		1000/= per 1Hr
		  		
		  	</p>
	  </div><!--home-col3/t3-->
	  <div class="home-col3">
	  	<button>
	  		<a href="login.php">CONFRIM your BOOKING>></a>
	  	</button>
	  	</div><!--home-col3/t3-->
	  	<div class="home-col4 ">
	  	<h2>[wp] JQ-0044</h2>
	  	<img src="img/trucks/t4.jpg">
		  	<p>
		  		VEHICLE- LAYLAND
		  		<br>
		  		DRIVER ID - 3434JQ
		  		<br>
		  		DRIVER NAME - Mali
		  		<br>
		  		TEL.NO - 070xxxxxxxx
		  		<br>
		  		1000/= per 1Hr
		  		
		  	</p>
	  </div><!--home-col4/t4-->
	  <div class="home-col4">
	  	<button>
	  		<a href="login.php">CONFRIM your BOOKING>></a>
	  	</button>
	  	</div><!--home-col4/t4-->
	  	<div class="home-col5 ">
	  	<h2>[wp] JK-0044</h2>
	  	<img src="img/trucks/t5.jpg">
		  	<p>
		  		VEHICLE- LAYLAND
		  		<br>
		  		DRIVER ID - 3434JK
		  		<br>
		  		DRIVER NAME - Anil
		  		<br>
		  		TEL.NO - 070xxxxxxxx
		  		<br>
		  		1000/= per 1Hr
		  		 
		  	</p>
	  </div><!--home-col4/t5-->
	  <div class="home-col5">
	  	<button>
	  		<a href="login.php">CONFRIM your BOOKING>></a>
	  	</button>
	  	</div><!--home-col4/t5-->
		 
<?php
  session_start();   //start the session
  include("footer.php");   //footer
?> 	 