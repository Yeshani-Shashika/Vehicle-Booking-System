<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" type="text/css" href="css/mainpia.css">
</head>

<body>
   <div class="wrapper">
    <div class="logo">
             <img src="img/45.png">
	</div> <!--logo-->
	
	
	 <div class="home">
	     <nav class="clearfix">
		     <ul>
			     <li><a href="index.php"> home </a></li>
				 <li><a href="maincat.php"> vehicles</a></li>
				 <li><a href="AboutUs.php"> about us</a></li>
				 <li><a href="ContactUs.php"> customer care</a></li>
				 <li><a href="register_1.php">  register now</a></li>
				 <li><a href="login.php"> login</a></li>
				 <li><a href="select.php"> my account</a></li>
			 </ul>
		 </nav>
		 </div>  <!--home-->
		 
		  <div class="home-col1 ">
	  	<h2>[wp] AAB-2244</h2>
	  	<img src="img/piageo/p1.jpg">
		  	<p>
		  		VEHICLE- PIAGEO
		  		<br>
		  		DRIVER ID - 3024AAB
		  		<br>
		  		DRIVER NAME - Nimal
		  		<br>
		  		TEL.NO - 077xxxxxxxx
		  		<br>
		  		50/= per 1KM
		  		
		  	</p>
	  </div><!--home-col1/p1-->
	  <div class="home-col1">
	  	<button>
	  		<a href="login.php">CONFRIM your BOOKING>></a>
	  	</button>
	  	</div><!--home-col1/p1-->
	  	<div class="home-col2 ">
	  	<h2>[wp] AAV-1244</h2>
	  	<img src="img/piageo/p2.jpg">
		  	<p>
		  		VEHICLE- PIAGEO
		  		<br>
		  		DRIVER ID - 3014JZ
		  		<br>
		  		DRIVER NAME - Amal
		  		<br>
		  		TEL.NO - 071xxxxxxxx
		  		<br>
		  		50/= per 1KM
		  		
		  	</p>
	  </div><!--home-col2/p2-->
	  <div class="home-col2">
	  	<button>
	  		<a href="login.php">CONFRIM your BOOKING>></a>
	  	</button>
	  	</div><!--home-col2/p2-->
	  		<div class="home-col3 ">
	  	<h2>[wp] NV-1244</h2>
	  	<img src="img/piageo/p3.jpg">
		  	<p>
		  		VEHICLE- KUBOTA
		  		<br>
		  		DRIVER ID - 3034NV
		  		<br>
		  		DRIVER NAME - Kamal
		  		<br>
		  		TEL.NO - 078xxxxxxxx
		  		<br>
		  		30/= per 1KM
		  		
		  	</p>
	  </div><!--home-col3/p3-->
	  <div class="home-col3">
	  	<button>
	  		<a href="login.php">CONFRIM your BOOKING>></a>
	  	</button>
	  	</div><!--home-col3/p3-->
	  	<div class="home-col4 ">
	  	<h2>[wp] QA-0044</h2>
	  	<img src="img/piageo/p4.jpg">
		  	<p>
		  		VEHICLE- KUBOTA
		  		<br>
		  		DRIVER ID - 3434QA
		  		<br>
		  		DRIVER NAME - Mali
		  		<br>
		  		TEL.NO - 070xxxxxxxx
		  		<br>
		  		30/= per 1KM
		  		
		  	</p>
	  </div><!--home-col4/p4-->
	  <div class="home-col4">
	  	<button>
	  		<a href="login.php">CONFRIM your BOOKING>></a>
	  	</button>
	  	</div><!--home-col4/p4-->
	  	<div class="home-col5 ">
	  	<h2>[wp] QZ-0044</h2>
	  	<img src="img/piageo/p5.png">
		  	<p>
		  		VEHICLE- PIAGEO
		  		<br>
		  		DRIVER ID - 3434QZ
		  		<br>
		  		DRIVER NAME - Anil
		  		<br>
		  		TEL.NO - 070xxxxxxxx
		  		<br>
		  		50/= per 1KM
		  		 
		  	</p>
	  </div><!--home-col4/p5-->
	  <div class="home-col5">
	  	<button>
	  		<a href="login.php">CONFRIM your BOOKING>></a>
	  	</button>
	  	</div><!--home-col4/p5-->
		 
<?php
  session_start();   //start the session
  include("footer.php");   //footer
?> 	 	 
		 