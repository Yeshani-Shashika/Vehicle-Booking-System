<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" type="text/css" href="css/mainsemi-lux.css">
</head>

<body>
   <div class="wrapper">
    <div class="logo">
             <img src="img/45.png">
	</div> <!--logo-->
	
	
	 <div class="home">
	     <nav class="clearfix">
		     <ul>
			     <li><a href="index.php"> home </a></li>
				 <li><a href="maincat.php"> vehicles</a></li>
				 <li><a href="AboutUs.php"> about us</a></li>
				 <li><a href="ContactUs.php"> customer care</a></li>
				 <li><a href="register_1.php">  register now</a></li>
				 <li><a href="select1.php"> login</a></li>
				 <li><a href="select.php"> my account</a></li>
			 </ul>
		 </nav>
		 </div>  <!--home-->
		 <div class="home-col1 ">
	  	<h2>[wp] AAB-2244</h2>
	  	<img src="img/semilcars/car1.jpg">
		  	<p>
		  		VEHICLE-Premio
		  		<br>
		  		DRIVER ID - 2024AAB
		  		<br>
		  		DRIVER NAME - Saman
		  		<br>
		  		TEL.NO - 077xxxxxxxx
		  		<br>
		  		150/= per 1KM
		  	</p>
	  </div><!--home-col1/semicar1-->
	  <div class="home-col1">
	  	<button>
	  		<a href="login.php">CONFRIM your BOOKING>></a>
	  	</button>
	  	</div><!--home-col1/semicar1-->
	  	<div class="home-col2 ">
	  	<h2>[wp] CCC-1244</h2>
	  	<img src="img/semilcars/car2.jpg">
		  	<p>
		  		VEHICLE-Allion
		  		<br>
		  		DRIVER ID - 2014CCC
		  		<br>
		  		DRIVER NAME - Kasun
		  		<br>
		  		TEL.NO - 071xxxxxxxx
		  		<br>
		  		150/= per 1KM
		  	</p>
	  </div><!--home-col2/semicar2-->
	  <div class="home-col2">
	  	<button>
	  		<a href="login.php">CONFRIM your BOOKING>></a>
	  	</button>
	  	</div><!--home-col2/semicar2-->
	  		<div class="home-col3 ">
	  	<h2>[wp] AAA-1244</h2>
	  	<img src="img/semilcars/car3.jpg">
		  	<p>
		  		VEHICLE-Prius
		  		<br>
		  		DRIVER ID - 2034AAA
		  		<br>
		  		DRIVER NAME - Nimal
		  		<br>
		  		TEL.NO - 078xxxxxxxx
		  		<br>
		  		150/= per 1KM
		  	</p>
	  </div><!--home-col3/semicar3-->
	  <div class="home-col3">
	  	<button>
	  		<a href="login.php">CONFRIM your BOOKING>></a>
	  	</button>
	  	</div><!--home-col3/semicar3-->
	  	<div class="home-col4 ">
	  	<h2>[wp] ACA-0044</h2>
	  	<img src="img/semilcars/car4.jpg">
		  	<p>
		  		VEHICLE-Aqua
		  		<br>
		  		DRIVER ID - 2434ACA
		  		<br>
		  		DRIVER NAME - Mali
		  		<br>
		  		TEL.NO - 070xxxxxxxx
		  		<br>
		  		150/= per 1KM
		  	</p>
	  </div><!--home-col4/semicar4-->
	  <div class="home-col4">
	  	<button>
	  		<a href="login.php">CONFRIM your BOOKING>></a>
	  	</button>
	  	</div><!--home-col4/semicar4-->
	  	<div class="home-col5 ">
	  	<h2>[wp] ACA-0044</h2>
	  	<img src="img/semilcars/car5.jpg">
		  	<p>
		  		VEHICLE-Yaris
		  		<br>
		  		DRIVER ID - 2434ACA
		  		<br>
		  		DRIVER NAME - Mali
		  		<br>
		  		TEL.NO - 070xxxxxxxx
		  		<br>
		  		150/= per 1KM
		  	</p>
	  </div><!--home-col4/semicar5-->
	  <div class="home-col5">
	  	<button>
	  		<a href="login.php">CONFRIM your BOOKING>></a>
	  	</button>
	  	</div><!--home-col4/semicar5-->
	  	

<?php
  session_start();   //start the session
  include("footer.php");   //footer
?>