<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" type="text/css" href="css/mainlux.css">
</head>

<body>
   <div class="wrapper">
    <div class="logo">
             <img src="img/45.png">
	</div> <!--logo-->
	
	
	 <div class="home">
	     <nav class="clearfix">
		     <ul>
			     <li><a href="index.php"> home </a></li>
				 <li><a href="maincat.php"> vehicles</a></li>
				 <li><a href="AboutUs.php"> about us</a></li>
				 <li><a href="ContactUs.php"> customer care</a></li>
				 <li><a href="register_1.php">  register now</a></li>
				 <li><a href="select1.php"> login</a></li>
				 <li><a href="select.php"> my account</a></li>
			 </ul>
		 </nav>
		 </div>  <!--home-->
		   <div class="home-col1 ">
	  	<h2>[wp] AAB-2244</h2>
	  	<img src="img/luxcars/car1.jpg">
		  	<p>
		  		VEHICLE-Benz
		  		<br>
		  		DRIVER ID - 3024AAB
		  		<br>
		  		DRIVER NAME - Saman
		  		<br>
		  		TEL.NO - 077xxxxxxxx
		  		<br>
		  		400/= per 1KM
		  	</p>
	  </div><!--home-col1/luxcar1-->
	  <div class="home-col1">
	  	<button>
	  		<a href="login.php">CONFRIM your BOOKING>></a>
	  	</button>
	  	</div><!--home-col1/luxcar1-->
	  	<div class="home-col2 ">
	  	<h2>[wp] CCC-1244</h2>
	  	<img src="img/luxcars/car2.jpg">
		  	<p>
		  		VEHICLE- BMW
		  		<br>
		  		DRIVER ID - 3014CCC
		  		<br>
		  		DRIVER NAME - Kasun
		  		<br>
		  		TEL.NO - 071xxxxxxxx
		  		<br>
		  		400/= per 1KM
		  	</p>
	  </div><!--home-col2/luxcar2-->
	  <div class="home-col2">
	  	<button>
	  		<a href="login.php">CONFRIM your BOOKING>></a>
	  	</button>
	  	</div><!--home-col2/luxcar2-->
	  		<div class="home-col3 ">
	  	<h2>[wp] AAA-1244</h2>
	  	<img src="img/luxcars/car3.jpg">
		  	<p>
		  		VEHICLE-Crown
		  		<br>
		  		DRIVER ID - 3034AAA
		  		<br>
		  		DRIVER NAME - Nimal
		  		<br>
		  		TEL.NO - 078xxxxxxxx
		  		<br>
		  		400/= per 1KM
		  	</p>
	  </div><!--home-col3/luxcar3-->
	  <div class="home-col3">
	  	<button>
	  		<a href="login.php">CONFRIM your BOOKING>></a>
	  	</button>
	  	</div><!--home-col3/luxcar3-->
	  	<div class="home-col4 ">
	  	<h2>[wp] ACA-0044</h2>
	  	<img src="img/luxcars/car4.jpg">
		  	<p>
		  		VEHICLE-BMW x5
		  		<br>
		  		DRIVER ID - 3434ACA
		  		<br>
		  		DRIVER NAME - Mali
		  		<br>
		  		TEL.NO - 070xxxxxxxx
		  		<br>
		  		600/= per 1KM
		  	</p>
	  </div><!--home-col4/luxcar4-->
	  <div class="home-col4">
	  	<button>
	  		<a href="login.php">CONFRIM your BOOKING>></a>
	  	</button>
	  	</div><!--home-col4/luxcar4-->
	  	<div class="home-col5 ">
	  	<h2>[wp] DBB-0544</h2>
	  	<img src="img/luxcars/car5.jpg">
		  	<p>
		  		VEHICLE- Limozine
		  		<br>
		  		DRIVER ID - 3434ACA
		  		<br>
		  		DRIVER NAME - Mali
		  		<br>
		  		TEL.NO - 070xxxxxxxx
		  		<br>
		  		1000/= per 1KM
		  	</p>
	  </div><!--home-col4/luxcar5-->
	  <div class="home-col5">
	  	<button>
	  		<a href="login.php">CONFRIM your BOOKING>></a>
	  	</button>
	  	</div><!--home-col4/luxcar5-->
		 
<?php
  session_start();   //start the session
  include("footer.php");   //footer
?> 