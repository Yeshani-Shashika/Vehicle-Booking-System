<?php
  include("header.php");  //nav bar and logo include home page
?>

<!DOCTYPE html>
<html>
<head>
	
</head>
<body>


	<link rel="stylesheet" type="text/css" href="css/maincat.css">

 <div class="home-col1 ">
	  	<h2>threewheels</h2>
	  	<img src="BAJAJ-RE-205cc-motorized-three-wheeler-17.png">
		  	<p>
		  		MAX passengers - 3
		  		<br>
		  		MAX luggage    - 1
		  	</p>
	  </div><!--home-col1/wheel-->
	  <div class="home-col1">
	  	<button>
	  		<a href="mainweel.php">BOOK now>></a>
	  	</button>
	  	</div><!--home-col1/wheel-->
	  	<div class="home-col2  ">
	  	<h2>bikes</h2>
	  	<img src="img/cat1/bikes/boxer.png">
		  	<p>
		  		MAX passengers - 1
		  		<br>
		  		MAX luggage    - 1
		  	</p>
	  </div><!--home-col2/bike-->
	  <div class="home-col2 ">
	  	<button>
	  		<a href="mainbike.php">BOOK now>></a>
	  	</button>
	  	</div><!--home-col2/bike-->
	  	<div class="home-col3  ">
	  	<h2>cars - economy</h2>
	  	<img src="img/cat1/smallcars.jpg">
		  	<p>
		  		MAX passengers - 4
		  		<br>
		  		MAX luggage    - 2
		  		<br>
		  		GEAR type      - M/A
		  		<br>
		  		A/C or non A/C


		  	</p>
	  </div><!--home-col3/light cars-->
	  <div class="home-col3 ">
	  	<button>
	  		<a href="maineconomy.php">BOOK now>></a>
	  	</button>
	  	</div><!--home-col3/light cars-->
	  	<div class="home-col4  ">
	  	<h2>cars - semi-luxrary</h2>
	  	<img src="img/cat1/semilucar.jpg">
		  	<p>
		  		MAX passengers - 5
		  		<br>
		  		MAX luggage    - 3
		  		<br>
		  		GEAR type      - A
		  		<br>
		  		A/C 
		  	

		  	</p>
	  </div><!--home-col4/semi-lu-cars-->
	  <div class="home-col4 ">
	  	<button>
	  		<a href="mainsemi-lux.php">BOOK now>></a>
	  	</button>
	  	</div><!--home-col4/semi-lu-cars-->
	  	<div class="home-col5  ">
	  	<h2>cars - luxrary</h2>
	  	<img src="img/cat1/luxerarycars.jpg">
		  	<p>
		  		MAX passengers - 5
		  		<br>
		  		MAX luggage    - 3
		  		<br>
		  		GEAR type      - A
		  		<br>
		  		A/C & Wi-Fi 
		  	

		  	</p>
	  </div><!--home-col5/lu-cars-->
	  <div class="home-col5 ">
	  	<button>
	  		<a href="mainlux.php">BOOK now>></a>
	  	</button>
	  	</div><!--home-col5/lu-cars-->
	  	<div class="home-col6  ">
	  	<h2>vans</h2>
	  	<img src="download.jpg">
		  	<p>
		  		MAX passengers - 5/10
		  		<br>
		  		MAX luggage    - 3/6
		  		<br>
		  		GEAR type      - A/M
		  		<br>
		  		A/C & Wi-Fi 
		  		<br>
		  		Phone Chargers 
		  		<br>
		  		Water
		  	

		  	</p>
	  </div><!--home-col6/vans-->
	  <div class="home-col6 ">
	  	<button>
	  		<a href="mainvan.php">BOOK now>></a>
	  	</button>
	  	</div><!--home-col6/vans-->
	  	<div class="home-col7  ">
	  	<h2>hardwere solutions - dousers</h2>
	  	<img src="img/cat1/douser.jpg">
		  	<p>
		  		BOOKING - two days ago
		  		<br>
		  		WORKING - 8hr per day
		  		<br>
		  		<br>
		  		
		  		CHARGES =
		  		<br>
		  		=800/= per hr 


		  	</p>
	  </div><!--home-col7/douser-->
	  <div class="home-col7 ">
	  	<button>
	  		<a href="maindouser.php">BOOK now>></a>
	  	</button>
	  	</div><!--home-col7/douser-->
	  	<div class="home-col8  ">
	  	<h2>hardwere solutions - excavetors</h2>
	  	<img src="img/cat1/excavator.jpg">
		  	<p>
		  		BOOKING - two days ago
		  		<br>
		  		WORKING - 8hr per day
		  		<br>
		  		<br>
		  		
		  		CHARGES =
		  		<br>
		  		=1000/= per hr 


		  	</p>
	  </div><!--home-col/excavetor-->
	  <div class="home-col8 ">
	  	<button>
	  		<a href="mainexca.php">BOOK now>></a>
	  	</button>
	  	</div><!--home-col8/excavetor-->
	  	
	  	<div class="home-col9  ">
	  	<h2>hardwere solutions - trucks</h2>
	  	<img src="img/cat1/trucks.jpg">
		  	<p>
		  		BOOKING - on time
		  		<br>
		  		WORKING - 8hr per day
		  		<br>
		  		<br>
		  		
		  		CHARGES =
		  		<br>
		  		=900/= per hr 


		  	</p>
	  </div><!--home-col8/trucks-->
	  <div class="home-col9 ">
	  	<button>
	  		<a href="maintruck.php">BOOK now>></a>
	  	</button>
	  	</div><!--home-col8/trucks-->
	  	<div class="home-col10  ">
	  	<h2>hardwere solutions - 3wheels</h2>
	  	<img src="img/cat1/piageo.png">
		  	<p>
		  		BOOKING - on time
		  		<br>
		  		WORKING - 8hr per day
		  		<br>
		  		<br>
		  		
		  		CHARGES =
		  		<br>
		  		workload


		  	</p>
	  </div><!--home-col10/piageo-->
	  <div class="home-col10 ">
	  	<button>
	  		<a href="mainpia.php">BOOK now>></a>
	  	</button>
	  	</div><!--home-col10/piageo-->
	  	
	  	





</body>
</html>

<?php
   include("footer.php");   //footer
?>