<?php
  include("header.php");  //nav bar and logo include home page
?>
<link rel="stylesheet" type="text/css" href="css/mainbike.css">

<div class="home-col1 ">
	  	<h2>[wp] AAB-2244</h2>
	  	<img src="img/bikes/boxer.png">
		  	<p>
		  		VEHICLE-bajaj-boxer
		  		<br>
		  		DRIVER ID - 1024AAB
		  		<br>
		  		DRIVER NAME - Saman
		  		<br>
		  		TEL.NO - 077xxxxxxxx
		  		<br>
		  		40/= per 1KM
		  	</p>
	  </div><!--home-col1/bike1-->
	  <div class="home-col1">
	  	<button>
	  		<a href="login.php">CONFRIM your BOOKING>></a>
	  	</button>
	  	</div><!--home-col1/bike1-->
	  	<div class="home-col2 ">
	  	<h2>[wp] CCC-1244</h2>
	  	<img src="img/bikes/pept.jpg">
		  	<p>
		  		VEHICLE-tvs-pept
		  		<br>
		  		DRIVER ID - 1014CCC
		  		<br>
		  		DRIVER NAME - Kasun
		  		<br>
		  		TEL.NO - 071xxxxxxxx
		  		<br>
		  		40/= per 1KM
		  	</p>
	  </div><!--home-col2/bike2-->
	  <div class="home-col2">
	  	<button>
	  		<a href="login.php">CONFRIM your BOOKING>></a>
	  	</button>
	  	</div><!--home-col2/bike2-->
	  		<div class="home-col3 ">
	  	<h2>[wp] AAA-1244</h2>
	  	<img src="img/bikes/bike3.jpg">
		  	<p>
		  		VEHICLE-honda-dio
		  		<br>
		  		DRIVER ID - 1034AAA
		  		<br>
		  		DRIVER NAME - Nimal
		  		<br>
		  		TEL.NO - 078xxxxxxxx
		  		<br>
		  		40/= per 1KM
		  	</p>
	  </div><!--home-col3/bike3-->
	  <div class="home-col3">
	  	<button>
	  		<a href="login.php">CONFRIM your BOOKING>></a>
	  	</button>
	  	</div><!--home-col3/wheel3-->
	  	<div class="home-col4 ">
	  	<h2>[wp] ACA-0044</h2>
	  	<img src="img/bikes/bike4.jpg">
		  	<p>
		  		VEHICLE-bajaj(2stroke)
		  		<br>
		  		DRIVER ID - 1434ACA
		  		<br>
		  		DRIVER NAME - Mali
		  		<br>
		  		TEL.NO - 070xxxxxxxx
		  		<br>
		  		40/= per 1KM
		  	</p>
	  </div><!--home-col4/bike4-->
	  <div class="home-col4">
	  	<button>
	  		<a href="login.php">CONFRIM your BOOKING>></a>
	  	</button>
	  	</div><!--home-col4/bike4-->
	  	

<?php
   include("footer.php");   //footer
?>