<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" type="text/css" href="css/AboutUs.css">
    <style>
    	
p{
	text-align: justify;
	font-size: 25px;
}

    </style>
	
</head>

<body>
  
	
	
	 <div class="home">
	     <nav class="clearfix">
		     <ul>
			     <li><a href="index.php"> home </a></li>
				 <li><a href="maincat.php"> vehicles</a></li>
				 <li><a href="AboutUs.php"> about us</a></li>
				 <li><a href="ContactUs.php"> customer care</a></li>
				 <li><a href="register_1.php">  register now</a></li>
				 <li><a href="select1.php"> login</a></li>
				 <li><a href="select.php"> my account</a></li>
			 </ul>
		 </nav>
	   
	 </div> <!--home-->
	 </div> <!--wrapper-->
	 <div class = "wrapper content">
	 <p style = "font-size:60px; margin:10px auto; color:rgba(252,183,80);">About Us</p>
	 <br>
	 
<h1>S.S.Gamage - Group Leader</h1>

<br><h3>Contact No:- 0713392537</h3>
<br><br><br>
<h2><u>Group Members</u></h2>
<br><br>
<ul>
	
<p>
	S . S. Gamage                       <br>MA-DSE-20-1F-023   - Customer Care page & Login <br><br>
    H. M. P. Hirushini Gunasekara      <br> MA-DSE-20-1F-017   - Register Now page & Vehicles page <br><br>
    Yeshani Shashika                 <br>MA-DSE-20-1F-043   - Home page & DataBase<br><br>
    Hiruni Ishara                    <br>MA-DSE-20-1F-047   - My Account Page

</p>	
</ul>


	  </body>
	  </html>
	 