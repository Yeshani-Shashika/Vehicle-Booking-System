<?php
  include("header.php");  //nav bar and logo include home page
?>
<link rel="stylesheet" type="text/css" href="css/maineconomy.css">

 <div class="home-col1 ">
	  	<h2>[wp] AAB-2244</h2>
	  	<img src="img/ecocar/ecar1.jpg">
		  	<p>
		  		VEHICLE-chevrolet
		  		<br>
		  		DRIVER ID - 2024AAB
		  		<br>
		  		DRIVER NAME - Saman
		  		<br>
		  		TEL.NO - 077xxxxxxxx
		  		<br>
		  		50/= per 1KM
		  	</p>
	  </div><!--home-col1/ecar1-->
	  <div class="home-col1">
	  	<button>
	  		<a href="login.php">CONFRIM your BOOKING>></a>
	  	</button>
	  	</div><!--home-col1/ecar1-->
	  	<div class="home-col2 ">
	  	<h2>[wp] CCC-1244</h2>
	  	<img src="img/ecocar/ecar2jpg.jpg">
		  	<p>
		  		VEHICLE-dihatzu
		  		<br>
		  		DRIVER ID - 2014CCC
		  		<br>
		  		DRIVER NAME - Kasun
		  		<br>
		  		TEL.NO - 071xxxxxxxx
		  		<br>
		  		50/= per 1KM
		  	</p>
	  </div><!--home-col2/ecar2-->
	  <div class="home-col2">
	  	<button>
	  		<a href="login.php">CONFRIM your BOOKING>></a>
	  	</button>
	  	</div><!--home-col2/ecar2-->
	  		<div class="home-col3 ">
	  	<h2>[wp] AAA-1244</h2>
	  	<img src="img/ecocar/ecars3.jpg">
		  	<p>
		  		VEHICLE-wageon-R
		  		<br>
		  		DRIVER ID - 2034AAA
		  		<br>
		  		DRIVER NAME - Nimal
		  		<br>
		  		TEL.NO - 078xxxxxxxx
		  		<br>
		  		50/= per 1KM
		  	</p>
	  </div><!--home-col3/ecar3-->
	  <div class="home-col3">
	  	<button>
	  		<a href="login.php">CONFRIM your BOOKING>></a>
	  	</button>
	  	</div><!--home-col3/ecar3-->
	  	<div class="home-col4 ">
	  	<h2>[wp] ACA-0044</h2>
	  	<img src="img/ecocar/ecar4.jpg">
		  	<p>
		  		VEHICLE-alto
		  		<br>
		  		DRIVER ID - 2434ACA
		  		<br>
		  		DRIVER NAME - Mali
		  		<br>
		  		TEL.NO - 070xxxxxxxx
		  		<br>
		  		50/= per 1KM
		  	</p>
	  </div><!--home-col4/ecar4-->
	  <div class="home-col4">
	  	<button>
	  		<a href="login.php">CONFRIM your BOOKING>></a>
	  	</button>
	  	</div><!--home-col4/ecar4-->
	  	<div class="home-col5 ">
	  	<h2>[wp] ACA-0044</h2>
	  	<img src="img/ecocar/ecar5.jpg">
		  	<p>
		  		VEHICLE-hihundai
		  		<br>
		  		DRIVER ID - 2434ACA
		  		<br>
		  		DRIVER NAME - Mali
		  		<br>
		  		TEL.NO - 070xxxxxxxx
		  		<br>
		  		50/= per 1KM
		  	</p>
	  </div><!--home-col4/ecar-->
	  <div class="home-col5">
	  	<button>
	  		<a href="login.php">CONFRIM your BOOKING>></a>
	  	</button>
	  	</div><!--home-col4/ecar5-->

<?php
   include("footer.php");   //footer
?>