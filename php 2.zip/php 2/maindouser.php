<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" type="text/css" href="css/maindouser.css">
</head>

<body>
   <div class="wrapper">
    <div class="logo">
             <img src="img/45.png">
	</div> <!--logo-->
	
	
	 <div class="home">
	     <nav class="clearfix">
		     <ul>
			     <li><a href="index.php"> home </a></li>
				 <li><a href="maincat.php"> vehicles</a></li>
				 <li><a href="AboutUs.php"> about us</a></li>
				 <li><a href="CntactUs.php"> customer care</a></li>
				 <li><a href="register_1.php">  register now</a></li>
				 <li><a href="select1.php"> login</a></li>
				 <li><a href="select.php"> my account</a></li>
			 </ul>
		 </nav>
		 </div>  <!--home-->
		 
		  <div class="home-col1 ">
	  	<h2>[wp] JB-2244</h2>
	  	<img src="img/douser/d1.jpg">
		  	<p>
		  		VEHICLE- CAT-JCB
		  		<br>
		  		DRIVER ID - 3024JB
		  		<br>
		  		DRIVER NAME - Saman
		  		<br>
		  		TEL.NO - 077xxxxxxxx
		  		<br>
		  		1800/= per 1Hr
		  		
		  	</p>
	  </div><!--home-col1/douser1-->
	  <div class="home-col1">
	  	<button>
	  		<a href="login.php">CONFRIM your BOOKING>></a>
	  	</button>
	  	</div><!--home-col1/douser1-->
	  	<div class="home-col2 ">
	  	<h2>[wp] JC-1244</h2>
	  	<img src="img/douser/d2.jpg">
		  	<p>
		  		VEHICLE- CAT-JCB
		  		<br>
		  		DRIVER ID - 3014JC
		  		<br>
		  		DRIVER NAME - Kasun
		  		<br>
		  		TEL.NO - 071xxxxxxxx
		  		<br>
		  		1800/= per 1Hr
		  		
		  	</p>
	  </div><!--home-col2/douser2-->
	  <div class="home-col2">
	  	<button>
	  		<a href="login.php">CONFRIM your BOOKING>></a>
	  	</button>
	  	</div><!--home-col2/douser2-->
	  		<div class="home-col3 ">
	  	<h2>[wp] JA-1244</h2>
	  	<img src="img/douser/d3.jpg">
		  	<p>
		  		VEHICLE- CAT-JCB
		  		<br>
		  		DRIVER ID - 3034JA
		  		<br>
		  		DRIVER NAME - Nimal
		  		<br>
		  		TEL.NO - 078xxxxxxxx
		  		<br>
		  		1800/= per 1Hr
		  		
		  	</p>
	  </div><!--home-col3/douser3-->
	  <div class="home-col3">
	  	<button>
	  		<a href="login.php">CONFRIM your BOOKING>></a>
	  	</button>
	  	</div><!--home-col3/douser3-->
	  	<div class="home-col4 ">
	  	<h2>[wp] JQ-0044</h2>
	  	<img src="img/douser/d4.jpg">
		  	<p>
		  		VEHICLE- CAT-JCB
		  		<br>
		  		DRIVER ID - 3434JQ
		  		<br>
		  		DRIVER NAME - Mali
		  		<br>
		  		TEL.NO - 070xxxxxxxx
		  		<br>
		  		1800/= per 1Hr
		  		
		  	</p>
	  </div><!--home-col4/douser4-->
	  <div class="home-col4">
	  	<button>
	  		<a href="login.php">CONFRIM your BOOKING>></a>
	  	</button>
	  	</div><!--home-col4/douser4-->
	  	<div class="home-col5 ">
	  	<h2>[wp] JK-0044</h2>
	  	<img src="img/douser/d5.jpg">
		  	<p>
		  		VEHICLE- CAT-JCB
		  		<br>
		  		DRIVER ID - 3434JK
		  		<br>
		  		DRIVER NAME - Anil
		  		<br>
		  		TEL.NO - 070xxxxxxxx
		  		<br>
		  		1800/= per 1Hr
		  		 
		  	</p>
	  </div><!--home-col4/douser5-->
	  <div class="home-col5">
	  	<button>
	  		<a href="login.php">CONFRIM your BOOKING>></a>
	  	</button>
	  	</div><!--home-col4/douser5-->
	  	
		 
<?php
  session_start();   //start the session
  include("footer.php");   //footer
?> 	 